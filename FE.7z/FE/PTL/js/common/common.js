var config = {
    // baseUrl: 'http://10.89.165.115/ApiForBaoBiao/api/', // HA
    // baseUrl: 'http://10.86.17.38/ApiForBaoBiao/api/', // QHD
    baseUrl: 'http://10.182.34.152/ApiForBaoBiao/api/', // SZ
    // baseUrl: 'http://localhost:44439/api/',

    account: [
        {
            userName: 'G1407961',
            password: 'G1407961',
            permission: 'Admin'
        },
        {
            userName: 'F0719949',
            password: 'F0719949',
            permission: 'Admin'
        },
        {
            userName: 'G1436038',
            password: 'G1436038',
            permission: 'Viewer'
        }
    ]
}

function ArrFind() {
    if (!Array.prototype.find) {
        Array.prototype.find = function (callback) {
            return callback && (this.filter(callback) || [])[0];
        };
    }
}

function ArrFilter() {
    if (!Array.prototype.filter) {
        Array.prototype.filter = function (fun) {
            var len = this.length;
            if (typeof fun != "function") {
                throw new TypeError();
            }
            var res = new Array();
            var thisp = arguments[1];
            for (var i = 0; i < len; i++) {
                if (i in this) {
                    var val = this[i];
                    if (fun.call(thisp, val, i, this)) {
                        res.push(val);
                    }
                }
            }
            return res;
        }
    }
}

ArrFind();
ArrFilter();

// 格式化時間
Date.prototype.Format = function (fmt) {
    var o = {
        "M+": this.getMonth() + 1, //月份
        "d+": this.getDate(), //日
        "h+": this.getHours(), //小时
        "m+": this.getMinutes(), //分
        "s+": this.getSeconds(), //秒
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度
        "S": this.getMilliseconds() //毫秒
    }
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}