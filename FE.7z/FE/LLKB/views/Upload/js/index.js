var configSelf = {
    title: {
        'V_SITE': '基地',
        'V_BU': 'BU',
        'V_FACNO': '工廠',
        'LOTNUM': '批號',
        'PARTNUM': '料號',
        'WORKTYPE': '生產類別',
        'LAYERNUM': '層數',
        'LAYER': '層別',
        'WORKNO': '工令',
        'TNUM': '檢驗數量',
        'TGNUM': '檢驗良品數',
        'TDATE': '檢驗日期',
        'SNUM': 'strip排版數',
        'PAREA': 'PCS面積',
        'TTYPE': '檢驗類型',
        'SAREA': 'SPNL面積',
        'YIELD': '良率'
    }
}