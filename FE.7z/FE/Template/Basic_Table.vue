<template>
    <div>
        666
    </div>
</template>

<script>
    module.exports = {
        data() {
            return {
            }
        },

        methods: {

        }
    }
</script>

<style>
    
</style>