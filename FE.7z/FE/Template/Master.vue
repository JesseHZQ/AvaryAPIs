<template>
    <div>
        <div class="sidebar">
            <img class="sidebar-logo" src="./img/Avary.png" alt="">
            <i-menu width="200px">
                <submenu v-for="(item, index) in menuList" :key="index" :name="item.name">
                    <template slot="title">
                        <img class="big-ico" src="./img/folder.png" alt="">
                        {{ item.title }}
                    </template>
                    <menu-item v-for="(it, index) in item.children" :key="index" :name="it.name" :to="it.to">
                        <img class="small-ico" src="./img/file.png" alt="">
                        {{ it.title }}
                    </menu-item>
                </submenu>
            </i-menu>
        </div>
        <div class="home-header">
            <div class="home-left">
                <img @click="changeClass" class="toggle" src="./img/menu.png" alt="" srcset="">
            </div>
            <h1 class="home-center">EMCS 品質平臺系統</h1>
        </div>
        <router-view class="content"></router-view>
    </div>
</template>

<script>
    module.exports = {
        data() {
            return {
                menuList: config.menuList
            }
        },

        methods: {
            changeClass: function () {
                var sidebar = document.querySelector('.sidebar')
                var header = document.querySelector('.home-header')
                var content = document.querySelector('.content')

                sidebar.classList.toggle('sidebar-collapse')
                header.classList.toggle('header-collapse')
                content.classList.toggle('content-collapse')
            }
        }
    }
</script>

<style>
    .home-header {
        transition: all .2s;
        height: 64px;
        padding-left: 200px;
        background: #fff;
        box-shadow: 0 2px 2px 1px #ddd;
        box-sizing: border-box;
    }

    .home-right {
        width: 150px;
        float: right;
        line-height: 64px;
    }

    .home-left {
        width: 150px;
        float: left;
    }

    .home-center {
        line-height: 64px;
        text-align: center;
        margin-left: 150px;
        margin-right: 150px;
    }

    .sidebar {
        transition: all .2s;
        width: 200px;
        height: 100vh;
        position: fixed;
        background: rgb(81, 90, 110);
        color: #fff;
        overflow: auto;
    }

    .sidebar .sidebar-logo {
        width: 170px;
        padding: 12px 18px;
    }

    .content {
        transition: all .2s;
        position: absolute;
        left: 200px;
        top: 65px;
        bottom: 0;
        right: 0;
        overflow: auto;
        min-width: 1166px;
    }

    .header-collapse {
        padding-left: 0;
    }

    .sidebar-collapse {
        width: 0;
    }

    .content-collapse {
        left: 0;
    }

    .toggle {
        float: left;
        height: 32px;
        margin: 16px 10px 0 10px;
    }

    .sidebar::-webkit-scrollbar {
        width: 6px;
        height: 1px;
    }

    .content::-webkit-scrollbar {
        width: 10px;
        height: 1px;
    }

    .sidebar::-webkit-scrollbar-thumb {
        border-radius: 2px;
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        background: #fff;
    }

    .content::-webkit-scrollbar-thumb {
        border-radius: 5px;
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        background: #ededed;
    }

    ::-webkit-scrollbar-track {
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        border-radius: 10px;
        background: rgb(81, 90, 110);
    }

    .ivu-menu-vertical .ivu-menu-submenu-title {
        padding: 10px 8px;
    }

    .ivu-menu-vertical .ivu-menu-item {
        padding: 6px;
    }

    .ivu-menu-vertical .ivu-menu-submenu-title-icon {
        right: 4px;
    }

    .ivu-menu-item {
        font-size: 12px;
    }

    .ivu-menu-vertical .ivu-menu-submenu .ivu-menu-item {
        padding-left: 20px !important;
    }

    .ivu-menu {
        color: #fff;
    }

    .ivu-menu-light {
        background-color: rgb(81, 90, 110);
    }

    .ivu-menu-vertical.ivu-menu-light:after {
        background-color: rgb(81, 90, 110);
    }

    .big-ico {
        float: left;
        height: 20px;
        margin-right: 8px;
    }

    .small-ico {
        float: left;
        height: 20px;
        margin-right: 8px;
    }
</style>