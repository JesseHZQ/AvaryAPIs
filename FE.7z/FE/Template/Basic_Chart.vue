<template>
    <div>
        999
    </div>
</template>

<script>
    module.exports = {
        data() {
            return {
            }
        },

        created() {
            this.test()
        },

        methods: {
            test() {
                // var arr = ['1', '666', '66']
                // var o = arr.filter(x => x.indexOf('6') > -1)

                console.log(666)
            }
        }
    }
</script>

<style>
    
</style>