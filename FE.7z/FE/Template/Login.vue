<template>
    <div class="bg">
        <div class="login">
            <div style="text-align: center;">
                <img class="logo" src="./img/Avary.png" alt="" srcset="">
                <p class="title">SMA良率系統</p>

                <i-form style="position: relative;" ref="form" :model="formData" label-width="60">
                    <form-item label="用戶名" prop="user">
                        <i-input ref="username" type="text" v-model="formData.USERID" placeholder="Username">
                            <Icon type="ios-person-outline" slot="prepend"></Icon>
                        </i-input>
                    </form-item>
                    <form-item label="密碼" prop="password">
                        <i-input ref="password" type="password" v-model="formData.MD_PWD" placeholder="Password">
                            <Icon type="ios-lock-outline" slot="prepend"></Icon>
                        </i-input>
                    </form-item>
                    <i-button style="margin-bottom: 40px;" type="primary" :loading="loginLoading" long @click="login">
                        {{ loginMsg }}
                    </i-button>
                    <p v-show="isError" class="errorMsg">{{ errorMsg }}</p>
                </i-form>
                <p style="margin-bottom: 10px;"> [技術支持:資訊科技處] </p>
                <p>[系統維護:趙慶磊 分機: 571-17520]</p>
            </div>
        </div>
    </div>
</template>

<script>
    module.exports = {
        data() {
            return {
                isError: false,
                errorMsg: '',
                loginLoading: false,
                loginMsg: '登錄',
                formData: {
                    USERID: '',
                    MD_PWD: ''
                }
            }
        },
        mounted: function () {
            this.$refs["username"].focus()
        },

        methods: {
            login: function () {
                var that = this
                that.formData.USERID = that.formData.USERID.trim()
                that.formData.MD_PWD = that.formData.MD_PWD.trim()
                if (that.formData.USERID && that.formData.MD_PWD) {
                    that.errorMsg = ''
                    that.loginLoading = true
                    that.loginMsg = '登錄中'

                    setTimeout(function () {
                        that.loginLoading = false
                        var flag = false
                        var userInfo = null
                        config.account.forEach(function (a) {
                            if (a.userName == that.formData.USERID && a.password == that
                                .formData.MD_PWD) {
                                flag = true
                                userInfo = a
                            }
                        });
                        if (flag) {
                            that.loginMsg = '登錄成功, 正在跳轉...'
                            sessionStorage.setItem('UserId', JSON.stringify(userInfo))
                            setTimeout(function () {
                                location.href = "views/Report/index.html"
                            }, 500)
                        } else {
                            that.isError = true
                            that.formData.MD_PWD = ''
                            that.loginMsg = '登錄'
                            that.errorMsg = '帳號或者密碼錯誤, 請重試！'
                            that.$refs["password"].focus()
                        }
                    }, 500);
                } else {
                    that.isError = true
                    that.errorMsg = '請輸入正確的帳號和密碼！'
                    that.$refs["username"].focus()
                }
            }
        }
    }
</script>

<style>
    .bg {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: url('./img/bg.jpg') no-repeat #000;
        background-size: cover;
        z-index: -1;
    }

    .login {
        width: 30%;
        min-width: 300px;
        height: 400px;
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        border-radius: 8px;
        padding: 20px;
        background-color: rgba(255, 255, 255, .7);
    }

    .login .logo {
        height: 40px;
        margin-bottom: 20px;
    }

    .login .title {
        font-size: 28px;
        font-weight: 700;
        margin-bottom: 20px;
        color: cadetblue;
    }

    .errorMsg {
        width: 100%;
        position: absolute;
        bottom: 10px;
        left: 50%;
        transform: translateX(-50%);
        color: #f00;
    }
</style>