var config = {
    // baseUrl: 'http://10.89.165.115/ApiForBaoBiao/api/', // HA
    // baseUrl: 'http://10.86.17.38/ApiForBaoBiao/api/', // QHD
    // baseUrl: 'http://10.182.34.152/ApiForBaoBiao/api/', // SZ
    baseUrl: 'http://localhost:44439/api/',

    menuList: [
        {
            title: '基础功能模板',
            name: 'jcgnmb',
            children: [
                {
                    title: '报表模板',
                    name: 'bbmb',
                    to: '/master/basic/table'
                },
                {
                    title: '图表模板',
                    name: 'tbmb',
                    to: '/master/basic/chart'
                }
            ]
        }
    ],

    account: [
        {
            userName: 'G1407961',
            password: 'G1407961',
            permission: 'Admin'
        },
        {
            userName: 'F0719949',
            password: 'F0719949',
            permission: 'Admin'
        },
        {
            userName: 'G1436038',
            password: 'G1436038',
            permission: 'Viewer'
        }
    ]
}