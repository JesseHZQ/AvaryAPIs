var router = new VueRouter({
    routes: [
        {
            path: '/',
            redirect: '/master'
        },
        {
            path: '/master',
            component: httpVueLoader('./Master.vue'),
            children: [
                {
                    path: 'basic/table',
                    component: httpVueLoader('./Basic_Table.vue')
                },
                {
                    path: 'basic/chart',
                    component: httpVueLoader('./Basic_Chart.vue')
                },
            ]
        },
        {
            path: '/login',
            component: httpVueLoader('./Login.vue')
        },
    ]
})