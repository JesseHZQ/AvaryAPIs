var config = {
    // baseUrl: 'http://10.89.165.115/ApiForBaoBiao/api/', // HA
    baseUrl: 'http://10.86.17.38/ApiForBaoBiao/api/', // QHD
    // baseUrl: 'http://10.182.34.152/ApiForBaoBiao/api/', // SZ
    // baseUrl: 'http://localhost:44439/api/',

    account: [
        {
            userName: 'admin',
            password: 'admin',
            permission: 'Admin'
        },
        {
            userName: 'G1407961',
            password: 'G1407961',
            permission: 'Admin'
        },
        {
            userName: 'F0719949',
            password: 'F0719949',
            permission: 'Admin'
        },
        {
            userName: 'G1436038',
            password: 'G1436038',
            permission: 'Viewer'
        },
        {
            userName: 'SZFPC',
            password: '888888',
            permission: 'Viewer'
        },
        {
            userName: 'PUBLIC',
            password: '888888',
            permission: 'Basic'
        }
    ],

    stationEn: {
        'SPI': 'SPI',
        'AOI': 'AOI',
        'XRAY': 'XRAY',
        '點膠': 'Dispending ',
        'COMPASS測(OQC)': 'COMPASS(OQC)',
        'COMPASS測(SMA)': 'COMPASS(SMA)',
        'CR測(OQC)': 'CR(OQC)',
        'CR測(SMA)': 'CR(SMA)',
        'FR測(OQC)': 'FR(OQC)',
        'FR測(SMA)': 'FR(SMA)',
        'FR測MIC1(OQC)': 'FR MIC1(OQC)',
        'FR測MIC4(OQC)': 'FR MIC4(OQC)',
        'ICT測(OQC)': 'ICT(OQC)',
        '功能測(OQC)': 'FCT(OQC)',
        '功能測(SMA)': 'FCT(SMA)',
        'VPP(SMA)': 'VPP(SMA)',
        '加熱測(OQC)': 'TCO(OQC)',
        '加熱測(SMA)': 'TCO(SMA)',
        '防水測(OQC)': 'Air leakage(OQC)',
        '防水測(SMA)': 'Air leakage(SMA)',
        '漏音測(OQC)': 'Sealing(OQC)',
        '漏音測(SMA)': 'Sealing(SMA)',
        '網分測(OQC)': 'RF(OQC)',
        '網分測(SMA)': 'RF(SMA)',
        'FQC': 'FQC',
        'OQC': 'OQC'
    },

    workTypeEn: {
        '全天': 'All Day',
        '白班': 'Day',
        '夜班': 'Night',
    },

    failEn: {
        '零件空焊': 'Component void solder ',
        '零件少錫': 'Component insufficient solder',
        '零件多錫': 'Component excess solder',
        '零件沾錫': 'Solder on component ',
        '零件錫球': 'Component solder ball',
        '零件錫尖': 'Component solder pointed',
        '零件錫裂': 'Component solder crack',
        '零件錫不熔': 'Component cold solder',
        '其他焊點不良': 'Other solder joints defect',
        '點膠裂紋': 'Glue crack',
        '零件沾膠': 'Glue on component',
        '點膠少膠': 'Insufficient glue',
        '漏點膠': 'Missing glue',
        '點膠气泡': 'Glue bubble',
        '點膠膠洞': 'Glue hole',
        '點膠未干': 'Glue wetting',
        '點膠溢膠': 'Glue overflow',
        '點膠毛絲&異物': 'Glue foreign material',
        '背膠偏位': 'PSA shift',
        '背膠脫落': 'PSA peeling off',
        // 特殊
        '背膠脱落': 'PSA peeling off',
        '背膠異物': 'PSA foreign material',
        // 特殊
        '背膠异物': 'PSA foreign material',
        '背膠漏貼': 'PSA missing',
        '背膠溢膠': 'PSA squeeze out',
        // 
        '背膠溢胶': 'PSA squeeze out',
        '背膠雙層': 'PSA double layer',
        // 
        '背膠双层': 'PSA double layer',
        '背膠氣泡': 'PSA bubble',
        '背膠缺膠': 'PSA damage',
        '背膠反離型': 'PSA stickiness',
        '軟板壓傷': 'Flex dent',
        '折線壓傷': 'Bending dent',
        '零件壓傷': 'Component dent',
        '鋼片壓傷': 'SUS dent',
        'PIN腳壓傷': 'PIN dent',
        '金面壓傷': 'Gold pad dent',
        '手指壓傷': 'Golden finger dent',
        '立體鋼片壓傷': 'Clip dent',
        '其它壓折傷': 'Other dent defect',
        'PET膜不良': 'PET film decect',
        'DOCK不良': 'Dock defect',
        'MIC不良': 'MIC defect',
        '金面不良': 'Gold pad defect',
        '加強片不良': 'Stiffener defect',
        'SW不良': 'Switch defect',
        'LED不良': 'LED defect',
        'BGA不良': 'BGA defect',
        '其它配件不良': 'Other parts defect',
        '缺件掉件': 'Missing parts',
        '錯件多件': 'Wrong/odd parts',
        '側立反白': 'Sideward/upside down',
        '浮翹立碑': 'Tilt/tombstone',
        '橋接反向': 'Solder bridge/opposite',
        '零件破損': 'Component damage',
        '零件剝離': 'Component peeling off',
        '零件偏位': 'Component shift',
        '其它零件不良': 'Other component defect',
        '軟板露銅': 'Flex exposed copper',
        // 
        '軟板漏銅': 'Flex exposed copper',
        '軟板異物': 'Flex foreign materials',
        '軟板錫渣': 'Flex solder splash',
        // 
        '軟板锡渣': 'Flex solder splash',
        '軟板沾膠': 'Glue on flex',
        // 
        '軟板粘膠': 'Glue on flex',
        '防焊不良': 'Solder mask defect',
        '沖型不良': 'Punching defect',
        'CVL不良': 'CVL defect',
        '漏折線': 'Missing bending',
        '其它軟板不良': 'Other flex defect',
        '軟板異色': 'Flex discoloration',
        '零件異色': 'Component discoloration',
        '手指異色': 'Golden finger discoloration',
        '金面異色': 'Gold pad discoloration',
        '髒污不良': 'Contamination defect',
        // 
        '臟污不良': 'Contamination defect',
        '油墨不良': 'Ink defect',
        '漆筆污染': 'Paint marker contamination',
        '軟板髒污': 'Flex contamination',
        // 
        '軟板臟污': 'Flex contamination',
        '軟板脏污': 'Flex contamination',
        '其它氧化污染': 'Other oxidization contamination',
        'FLUX不良': 'FLUX defect',
        '條碼不良': 'Barcode defect',
        '混料': 'Material mixing',
        '間隙不良': 'Gap defect',
        '零配件毛刺': 'Parts burr',
        '定位柱不入孔': 'Post PIN alignment shift',
        '孔內異物': 'Foreign material in hole',
        '零配件極性反': 'Parts polarity',
        '其他不良': 'Other defect',
        '焊點不良': 'Solder joints defect',
        '點膠不良': 'Dispending defect',
        '背膠不良': 'PSA defect',
        '壓折傷不良': 'Dent defect',
        '配件不良': 'Parts defect',
        '零件不良': 'Component defect',
        '軟板不良': 'Flex defect',
        '氧化污染': 'Oxidization contamination',
        '其它': 'Others',
        '其它不良': 'Others',

        '零件少锡': 'Component insufficient solder',
        '零件多锡': 'Component excess solder',
        '零件沾锡': 'Solder on component ',
        '零件锡球': 'Component solder ball',
        '零件锡尖': 'Component solder pointed',
        '零件锡裂': 'Component solder crack',
        '零件锡不熔': 'Component cold solder',
        '其他焊点不良': 'Other solder joints defect',
        '点胶裂纹': 'Glue crack',
        '零件沾胶': 'Glue on component',
        '点胶少胶': 'Insufficient glue',
        '漏点胶': 'Missing glue',
        '点胶气泡': 'Glue bubble',
        '点胶胶洞': 'Glue hole',
        '点胶未干': 'Glue wetting',
        '点胶溢胶': 'Glue overflow',
        '点胶毛丝&异物': 'Glue foreign material',
        '背胶偏位': 'PSA shift',
        '背胶脱落': 'PSA peeling off',
        '背胶异物': 'PSA foreign material',
        '背胶漏贴': 'PSA missing',
        '背胶溢胶': 'PSA squeeze out',
        '背胶双层': 'PSA double layer',
        '背胶气泡': 'PSA bubble',
        '背胶缺胶': 'PSA damage',
        '背胶反离型': 'PSA stickiness',
        '软板压伤': 'Flex dent',
        '折线压伤': 'Bending dent',
        '零件压伤': 'Component dent',
        '钢片压伤': 'SUS dent',
        'PIN脚压伤': 'PIN dent',
        '金面压伤': 'Gold pad dent',
        '手指压伤': 'Golden finger dent',
        '立体钢片压伤': 'Clip dent',
        '其它压折伤': 'Other dent defect',
        '加强片不良': 'Stiffener defect',
        '错件多件': 'Wrong/odd parts',
        '侧立反白': 'Sideward/upside down',
        '浮翘立碑': 'Tilt/tombstone',
        '桥接反向': 'Solder bridge/opposite',
        '零件破损': 'Component damage',
        '零件剥离': 'Component peeling off',
        '软板露铜': 'Flex exposed copper',
        '软板异物': 'Flex foreign materials',
        '软板锡渣': 'Flex solder splash',
        '软板沾胶': 'Glue on flex',
        '冲型不良': 'Punching defect',
        '漏折线': 'Missing bending',
        '其它软板不良': 'Other flex defect',
        '软板异色': 'Flex discoloration',
        '零件异色': 'Component discoloration',
        '手指异色': 'Golden finger discoloration',
        '金面异色': 'Gold pad discoloration',
        '脏污不良': 'Contamination defect',
        '漆笔污染': 'Paint marker contamination',
        '软板脏污': 'Flex contamination',
        '条码不良': 'Barcode defect',
        '间隙不良': 'Gap defect',
        '孔内异物': 'Foreign material in hole',
        '零配件极性反': 'Parts polarity',
        '焊点不良': 'Solder joints defect',
        '点胶不良': 'Dispending defect',
        '背胶不良': 'PSA defect',
        '压折伤不良': 'Dent defect',
        '软板不良': 'Flex defect',

        '加強片粘膠': 'Glue on stiffener',
        '防焊裂紋': 'Solder mask crack',
        'PAD錫不均': 'PAD solder non-uniform',
        'PAD锡不均': 'PAD solder non-uniform'
    },

    staSeq: {
        'SPI': 1,
        'AOI': 2,
        'XRAY': 3,
        '點膠': 4,
        'VPP(SMA)': 5,
        'CR測(SMA)': 6,
        'CR測(OQC)': 7,
        '網分測(SMA)': 8,
        '網分測(OQC)': 9,
        '漏音測(SMA)': 10,
        '漏音測(OQC)': 11,
        '加熱測(SMA)': 12,
        '加熱測(OQC)': 13,
        '功能測(SMA)': 14,
        '功能測(OQC)': 15,
        '轉盤測(SMA)': 16,
        '轉盤測(OQC)': 17,
        'COMPASS測(SMA)': 18,
        'COMPASS測(OQC)': 19,
        'FR測MIC1(OQC)': 20,
        'FR測MIC4(OQC)': 21,
        'FR測(SMA)': 22,
        'FR測(OQC)': 23,
        '防水測(SMA)': 24,
        '防水測(OQC)': 25,
        'ICT測(OQC)': 26,
        'FQC': 27,
        'OQC': 28
    }
}

function ArrFind() {
    if (!Array.prototype.find) {
        Array.prototype.find = function (callback) {
            return callback && (this.filter(callback) || [])[0];
        };
    }
}

function ArrFilter() {
    if (!Array.prototype.filter) {
        Array.prototype.filter = function (fun) {
            var len = this.length;
            if (typeof fun != "function") {
                throw new TypeError();
            }
            var res = new Array();
            var thisp = arguments[1];
            for (var i = 0; i < len; i++) {
                if (i in this) {
                    var val = this[i];
                    if (fun.call(thisp, val, i, this)) {
                        res.push(val);
                    }
                }
            }
            return res;
        }
    }
}

ArrFind();
ArrFilter();

// 格式化時間
Date.prototype.Format = function (fmt) {
    var o = {
        "M+": this.getMonth() + 1, //月份
        "d+": this.getDate(), //日
        "h+": this.getHours(), //小时
        "m+": this.getMinutes(), //分
        "s+": this.getSeconds(), //秒
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度
        "S": this.getMilliseconds() //毫秒
    }
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}