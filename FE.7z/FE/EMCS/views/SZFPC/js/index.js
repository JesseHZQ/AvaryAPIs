var configSelf = {
    title: {
        'FID': '項目ID',
        'CTRLITEM': '管制項目',
        'MEASDATE': '日期時間',
        'MEASDATA': '數據',
        // 'lotnum': '批號',
        // 'OAYDATE': 'OAY結批日期',
        // 'OAYEDATE': 'OAY結批日期',
        // 'datetime': '日期'
    }
}