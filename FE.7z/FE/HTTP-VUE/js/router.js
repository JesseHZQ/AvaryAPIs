var router = new VueRouter({
  mode: 'history',
  routes: [{
      path: '/foo',
      component:  { template: '<div>Hello World</div>'}//httpVueLoader('./demo.vue')
    },
    {
      path: '/bar',
      component: httpVueLoader('./demo2.vue')
    }
  ]
})