var config = {
    baseUrl: 'http://localhost:5842/api/'
}