<template>
    <div>
        <div class="searchArea">
            <div class="col">工站:</div>
            <i-select size="small" v-model="searchModel.PROC_G" style="width:100px">
                <i-option v-for="(item, index) in PROC_G_List" :value="item" :key="index">{{ item }}</i-option>
            </i-select>
            <div class="col">課別:</div>
            <i-select size="small" v-model="searchModel.GROUP_NAME" style="width:100px">
                <i-option v-for="(item, index) in GROUP_NAME_List" :value="item" :key="index">{{ item }}</i-option>
            </i-select>
            <div class="col">廠區:</div>
            <i-select size="small" v-model="searchModel.LOC" style="width:100px">
                <i-option v-for="(item, index) in LOC_List" :value="item" :key="index">{{ item }}</i-option>
            </i-select>
            <div class="col">錯誤日期:</div>
            <i-select size="small" v-model="searchModel.PDATE" style="width:100px">
                <i-option v-for="(item, index) in PDATE_List" :value="item" :key="index">{{ item }}</i-option>
            </i-select>
            <div class="col">幾種:</div>
            <i-select size="small" v-model="searchModel.JZ" style="width:100px">
                <i-option v-for="(item, index) in JZ_List" :value="item" :key="index">{{ item }}</i-option>
            </i-select>
        </div>
        <div class="searchArea">
            <div class="col">料號:</div>
            <i-select size="small" v-model="searchModel.PART" style="width:100px">
                <i-option v-for="(item, index) in PART_List" :value="item" :key="index">{{ item }}</i-option>
            </i-select>
            <div class="col">纖體:</div>
            <i-select size="small" v-model="searchModel.PLINE" style="width:100px">
                <i-option v-for="(item, index) in PLINE_List" :value="item" :key="index">{{ item }}</i-option>
            </i-select>
            <div class="col">檢測類型:</div>
            <i-select size="small" v-model="searchModel.ITEM" style="width:100px">
                <i-option v-for="(item, index) in ITEM_List" :value="item" :key="index">{{ item }}</i-option>
            </i-select>
            <div class="col">錯誤類型:</div>
            <i-select size="small" v-model="searchModel.ETYPE" style="width:100px">
                <i-option v-for="(item, index) in ETYPE_List" :value="item" :key="index">{{ item }}</i-option>
            </i-select>
            <i-button style="margin-left: 30px; width: 60px;" size="small" type="primary" @click="getData">Search
            </i-button>
            <i-button style="margin-left: 10px; width: 60px;" size="small" type="error" @click="clearData">Clear
            </i-button>
            <i-button style="margin-left: 10px;" size="small" type="success" @click="exportExcel" :loading="btnLoading">
                Export Excel
            </i-button>
        </div>
        <div style="padding: 0 20px;">
            <i-table border :loading="loading" size="small" height="400" :columns="columns" :data="data"></i-table>
        </div>
        <div style="text-align: right; margin: 10px 10px 10px 0;">
            <Page :total="total" :page-size="pageSize" :current="currentPage" @on-change="onPageChange" @on-page-size-change="onPageSizePage" show-total show-sizer />
        </div>
    </div>
</template>
 
<script>
    module.exports = {
        data() {
            return {
                tableWidth: null,
                columns: [{
                        title: '工站',
                        width: 80,
                        key: 'PROC_G'
                    },
                    {
                        title: '課別',
                        width: 100,
                        key: 'GROUP_NAME'
                    },
                    {
                        title: '廠區',
                        width: 80,
                        key: 'LOC'
                    },
                    {
                        title: '錯誤日期',
                        width: 100,
                        key: 'PDATE'
                    },
                    {
                        title: '幾種',
                        width: 140,
                        key: 'JZ'
                    },
                    {
                        title: '料號',
                        width: 140,
                        key: 'PART'
                    },
                    {
                        title: '纖體',
                        width: 100,
                        key: 'PLINE'
                    },
                    {
                        title: '檢測類型',
                        width: 100,
                        key: 'ITEM'
                    },
                    {
                        title: '錯誤類型',
                        width: 100,
                        key: 'ETYPE'
                    },
                    {
                        title: '第一次錯誤時間',
                        width: 140,
                        key: 'ESTARTTIME'
                    },
                    {
                        title: '最後一次錯誤時間',
                        width: 140,
                        key: 'EENDTIME'
                    },
                    {
                        title: '連續錯誤次數',
                        width: 130,
                        key: 'ECOUNT'
                    },
                    {
                        title: '標準良率',
                        width: 100,
                        key: 'GG_VALUE'
                    },
                    {
                        title: '第一次錯誤良率',
                        width: 140,
                        key: 'SJ_VALUE_1'
                    },
                    {
                        title: '第二次錯誤良率',
                        width: 140,
                        key: 'SJ_VALUE_2'
                    },
                    {
                        title: '第三次錯誤良率',
                        width: 140,
                        key: 'SJ_VALUE_3'
                    },
                    {
                        title: '第四次錯誤良率',
                        width: 140,
                        key: 'SJ_VALUE_4'
                    }
                ],
                data: [],
                loading: false,
                btnLoading: false,
                // search Model
                searchModel: {
                    PROC_G: null,
                    GROUP_NAME: null,
                    LOC: null,
                    PDATE: null,
                    JZ: null,
                    PART: null,
                    PLINE: null,
                    ITEM: null,
                    ETYPE: null
                },
                // select data
                PROC_G_List: null,
                GROUP_NAME_List: null,
                LOC_List: null,
                PDATE_List: null,
                JZ_List: null,
                PART_List: null,
                PLINE_List: null,
                ITEM_List: null,
                ETYPE_List: null,
                // pager
                total: 0,
                currentPage: 1,
                pageSize: 10
            }
        },
        computed: {
            start() {
                return (this.currentPage - 1) * this.pageSize + 1
            },
            end() {
                return this.currentPage * this.pageSize
            }
        },
        created: function() {
            this.getRowData()
            axios.get(config.baseUrl + 'PQM/GetDDList').then(res => {
                this.PROC_G_List = res.data.PROC_G
                this.GROUP_NAME_List = res.data.GROUP_NAME
                this.LOC_List = res.data.LOC
                this.PDATE_List = res.data.PDATE
                this.JZ_List = res.data.JZ
                this.PART_List = res.data.PART
                this.PLINE_List = res.data.PLINE
                this.ITEM_List = res.data.ITEM
                this.ETYPE_List = res.data.ETYPE
            })
        },
        mounted() {
            this.tableWidth = window.innerWidth
        },
        methods: {
            getRowData() {
                this.loading = true
                axios.post(config.baseUrl + 'PQM/GetData', { ...this.searchModel,
                    Start: this.start,
                    End: this.end
                }).then(res => {
                    this.total = res.data.Total
                    this.data = res.data.Data
                    this.loading = false
                })
            },
            getData() {
                this.currentPage = 1
                this.getRowData()
            },
            clearData() {
                this.searchModel.PROC_G = null
                this.searchModel.GROUP_NAME = null,
                    this.searchModel.LOC = null,
                    this.searchModel.PDATE = null,
                    this.searchModel.JZ = null,
                    this.searchModel.PART = null,
                    this.searchModel.PLINE = null,
                    this.searchModel.ITEM = null,
                    this.searchModel.ETYPE = null
            },
            onPageChange(page) {
                this.currentPage = page
                this.getRowData()
            },
            onPageSizePage(pageSize) {
                this.pageSize = pageSize
                this.getRowData()
            },
            exportExcel() {
                this.btnLoading = true
                axios.post(config.baseUrl + 'PQM/CreateExcel', this.searchModel).then(res => {
                    this.btnLoading = false
                    location.href = config.baseUrl + 'PQM/downloadFile?filePath=' + res.data + '&fileName=2.xlsx'
                })
            }
        }
    }
</script>
 
<style>

</style>