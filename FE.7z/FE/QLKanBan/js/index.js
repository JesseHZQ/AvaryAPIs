var config = {
    baseUrl: 'http://10.89.165.115/PQM-Alarm-Api/api/'
}