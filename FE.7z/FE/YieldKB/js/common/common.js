var config = {
    baseUrl: 'http://10.89.165.115/ApiForYieldKanBan/api/',
    // baseUrl: 'http://localhost:52506/api/',

    account: [
        {
            userName: 'admin',
            password: 'admin',
            permission: 'Admin'
        }
    ],

    menu: [
        // {
        //     name: '1',
        //     title: '良率報表',
        //     to: '../Report/index.html'
        // },
        {
            name: '1',
            title: '良率報表',
            isSub: true,
            children: [
                {
                    name: '1-1',
                    title: '統計報表',
                    to: '../Sum/index.html'
                },
                {
                    name: '1-2',
                    title: '詳情報表',
                    to: '../Report/index.html'
                }
            ]
        },
        {
            name: '2',
            title: '良率看板',
            isSub: true,
            children: [
                {
                    name: '2-0',
                    title: '匯總圖',
                    to: '../SumChart/index.html'
                },
                {
                    name: '2-1',
                    title: '良率趨勢圖',
                    to: '../YieldTrendChart/index.html'
                },
                {
                    name: '2-2',
                    title: '不良率趨勢圖',
                    to: '../NGTrendChart/index.html'
                },
                {
                    name: '2-3',
                    title: '不良項柏拉圖',
                    to: '../NGPlato/index.html'
                },
                {
                    name: '2-4',
                    title: '不良項熱點圖',
                    to: '../NGHeat/index.html'
                },
                {
                    name: '2-5',
                    title: '不良項堆疊圖',
                    to: '../NGStack/index.html'
                },
                {
                    name: '2-6',
                    title: 'OK2ship',
                    to: '../NGByLayer/index.html'
                },
                {
                    name: '2-7',
                    title: 'Mapping Short',
                    to: '../NGByPosition/index.html'
                }
            ]
        }
    ]
}

function GenerateCascader() {
    var factory = [
        {
            label: 'SZ',
            value: 'SZ'
        },
        {
            label: 'QHD',
            value: 'QHD'
        },
        {
            label: 'HA',
            value: 'HA'
        }
    ]

    var bu = [
        {
            label: 'FPC',
            value: 'FPC',
            children: [
                {
                    label: 'AOI',
                    value: 'AOI'
                }
            ]
        }
    ]

    var data = []

    for (var i = 0; i < factory.length; i++) {
        var d = {
            value: factory[i].value,
            label: factory[i].label,
            children: []
        }
        for (var j = 0; j < bu.length; j++) {
            var dd = {
                value: bu[j].value,
                label: bu[j].label,
                children: bu[j].children || []
            }
            d.children.push(dd)
        }
        data.push(d)
    }

    console.log(data)
    config.cascaderData = data
    config.cascaderValue = (localStorage.getItem('cascaderValue') ? JSON.parse(localStorage.getItem('cascaderValue')) : []) || ['SZ', 'FPC', 'AOI']
}

GenerateCascader()


function ArrFind() {
    if (!Array.prototype.find) {
        Array.prototype.find = function (callback) {
            return callback && (this.filter(callback) || [])[0];
        };
    }
}

function ArrFilter() {
    if (!Array.prototype.filter) {
        Array.prototype.filter = function (fun) {
            var len = this.length;
            if (typeof fun != "function") {
                throw new TypeError();
            }
            var res = new Array();
            var thisp = arguments[1];
            for (var i = 0; i < len; i++) {
                if (i in this) {
                    var val = this[i];
                    if (fun.call(thisp, val, i, this)) {
                        res.push(val);
                    }
                }
            }
            return res;
        }
    }
}

ArrFind();
ArrFilter();